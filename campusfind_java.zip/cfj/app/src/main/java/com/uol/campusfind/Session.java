package com.uol.campusfind;

import android.content.Context;
import android.content.SharedPreferences;

/** Keeps the user logged in until Logout, even after the app restarts (R2). */
public final class Session {
    private static final String PREFS = "campusfind_session";
    private static final String KEY = "uid";

    private Session() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void save(Context c, long uid) {
        prefs(c).edit().putLong(KEY, uid).commit();
    }

    public static void clear(Context c) {
        prefs(c).edit().remove(KEY).commit();
    }

    /** Returns the logged-in user or null. */
    public static User currentUser(Context c) {
        long id = prefs(c).getLong(KEY, -1);
        if (id < 0) return null;
        return DbHelper.get(c).getUserById(id);
    }
}
