package com.uol.campusfind;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NearbyFragment extends Fragment {
    private final LocationHelper loc = new LocationHelper(this);
    private ItemAdapter adapter;
    private ProgressBar progress;
    private TextView status, coords;
    private View retry, header, list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_nearby, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        progress = view.findViewById(R.id.progress);
        status = view.findViewById(R.id.tv_status);
        coords = view.findViewById(R.id.tv_coords);
        retry = view.findViewById(R.id.btn_retry);
        header = view.findViewById(R.id.header);
        list = view.findViewById(R.id.recycler);

        RecyclerView rv = view.findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), ItemDetailsActivity.class);
            i.putExtra(ItemDetailsActivity.EXTRA_ID, item.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);

        retry.setOnClickListener(v -> locate());
        view.findViewById(R.id.btn_refresh).setOnClickListener(v -> locate());
        locate();
    }

    private void showLoading() {
        progress.setVisibility(View.VISIBLE);
        status.setVisibility(View.GONE);
        retry.setVisibility(View.GONE);
        header.setVisibility(View.GONE);
        list.setVisibility(View.GONE);
    }

    private void showFailure(String msg) {
        progress.setVisibility(View.GONE);
        header.setVisibility(View.GONE);
        list.setVisibility(View.GONE);
        status.setText(msg);
        status.setVisibility(View.VISIBLE);
        retry.setVisibility(View.VISIBLE);
        Snackbar.make(requireView(), msg, Snackbar.LENGTH_LONG).show();
    }

    private void locate() {
        showLoading();
        loc.request(new LocationHelper.Callback() {
            @Override
            public void onLocation(Location l) {
                if (!isAdded()) return;
                List<Item> items = DbHelper.get(requireContext()).getAllItems();
                final Map<String, Float> dist = new HashMap<>();
                for (Item it : items) {
                    float[] r = new float[1];
                    Location.distanceBetween(l.getLatitude(), l.getLongitude(), it.lat, it.lng, r);
                    dist.put(it.id, r[0]);
                }
                // R7: sorted nearest first
                Collections.sort(items, (a, b) -> Float.compare(dist.get(a.id), dist.get(b.id)));
                Map<String, String> labels = new HashMap<>();
                for (Item it : items) labels.put(it.id, Utils.formatDistance(dist.get(it.id)) + " away");
                adapter.setData(items, labels);
                coords.setText("You: " + Utils.fmt5(l.getLatitude()) + ", " + Utils.fmt5(l.getLongitude()));
                progress.setVisibility(View.GONE);
                status.setVisibility(View.GONE);
                retry.setVisibility(View.GONE);
                header.setVisibility(View.VISIBLE);
                list.setVisibility(View.VISIBLE);
            }

            @Override
            public void onDenied() {
                if (isAdded()) showFailure("Location permission is required to find nearby items");
            }

            @Override
            public void onError() {
                if (isAdded()) showFailure("Could not get your location. Turn on GPS and try again.");
            }
        });
    }
}
