package com.uol.campusfind;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

public class ItemDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_ID = "item_id";

    private LinearLayout rows;
    private View btnMaps, btnReturned;
    private Item item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Item Details");
        }
        rows = findViewById(R.id.rows);
        btnMaps = findViewById(R.id.btn_maps);
        btnReturned = findViewById(R.id.btn_returned);

        btnMaps.setOnClickListener(v -> openMaps());
        btnReturned.setOnClickListener(v -> confirmReturn());
    }

    @Override
    protected void onResume() {
        super.onResume();
        item = DbHelper.get(this).getItem(getIntent().getStringExtra(EXTRA_ID));
        if (item == null) {
            finish();
            return;
        }
        render();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void addRow(String label, String value) {
        View row = LayoutInflater.from(this).inflate(R.layout.row_detail, rows, false);
        ((TextView) row.findViewById(R.id.tv_label)).setText(label);
        ((TextView) row.findViewById(R.id.tv_value)).setText(value);
        rows.addView(row);
    }

    private void render() {
        ((TextView) findViewById(R.id.tv_title)).setText(item.title);
        rows.removeAllViews();
        addRow("ID", item.id);
        addRow("Type", item.type);
        addRow("Category", item.category);
        addRow("Place", item.place);
        addRow("Date", Utils.prettyDate(item.date));
        addRow("Coordinates", Utils.fmt5(item.lat) + ", " + Utils.fmt5(item.lng));
        addRow("Reported by", item.reportedBy);
        addRow("Contact", item.contact);
        addRow("Status", item.isReturned() ? "Returned" : "Open");

        // R8: only the user who reported the item sees "Mark as Returned"
        User me = Session.currentUser(this);
        boolean mine = me != null && item.reportedByUid == me.id;
        btnReturned.setVisibility(mine && !item.isReturned() ? View.VISIBLE : View.GONE);
    }

    private void openMaps() {
        String lat = Utils.fmt5(item.lat), lng = Utils.fmt5(item.lng);
        Uri geo = Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng
                + "(" + Uri.encode(item.title) + ")");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, geo));
            return;
        } catch (ActivityNotFoundException ignored) {
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/maps/search/?api=1&query=" + lat + "," + lng)));
        } catch (ActivityNotFoundException e) {
            Snackbar.make(findViewById(android.R.id.content), "No maps app found on this device",
                    Snackbar.LENGTH_LONG).show();
        }
    }

    private void confirmReturn() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Mark as Returned?")
                .setMessage("\"" + item.title + "\" will be marked as returned.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Confirm", (d, w) -> {
                    DbHelper.get(this).markReturned(item.id);
                    item = DbHelper.get(this).getItem(item.id);
                    render();
                    Snackbar.make(findViewById(android.R.id.content), "Marked as returned",
                            Snackbar.LENGTH_LONG).show();
                })
                .show();
    }
}
