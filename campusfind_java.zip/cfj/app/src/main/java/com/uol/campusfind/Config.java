package com.uol.campusfind;

/** TODO: fill in your own team details before submission. */
public final class Config {
    public static final String TEAM_NAME = "YourTeamName";
    public static final String GITHUB_URL = "https://github.com/YourUser/AppNova-EntryID-TeamName";
    public static final String[] MEMBERS = {
            "Member 1 Name (SAP ID)",
            "Member 2 Name (SAP ID)",
            "Member 3 Name (SAP ID)"
    };

    private Config() {}
}
