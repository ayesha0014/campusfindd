package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNav;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // No app screen opens without login (R2).
        if (Session.currentUser(this) == null) {
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        bottomNav = findViewById(R.id.bottom_nav);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment f;
            String title;
            if (id == R.id.nav_home) {
                f = new HomeFragment();
                title = "CampusFind";
            } else if (id == R.id.nav_nearby) {
                f = new NearbyFragment();
                title = "Nearby Items";
            } else if (id == R.id.nav_report) {
                f = new ReportFragment();
                title = "Report an Item";
            } else {
                f = new ProfileFragment();
                title = "Profile";
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.container, f).commit();
            toolbar.setTitle(title);
            return true;
        });

        if (savedInstanceState == null) bottomNav.setSelectedItemId(R.id.nav_home);
    }

    public void selectTab(int menuId) {
        bottomNav.setSelectedItemId(menuId);
    }
}
