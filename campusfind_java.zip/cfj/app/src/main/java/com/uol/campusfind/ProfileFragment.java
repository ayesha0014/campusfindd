package com.uol.campusfind;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;

public class ProfileFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        User user = Session.currentUser(requireContext());
        TextView avatar = v.findViewById(R.id.tv_avatar);
        TextView name = v.findViewById(R.id.tv_name);
        TextView email = v.findViewById(R.id.tv_email);
        TextView team = v.findViewById(R.id.tv_team);
        TextView github = v.findViewById(R.id.tv_github);

        if (user != null) {
            avatar.setText(user.name.substring(0, 1).toUpperCase());
            name.setText(user.name);
            email.setText(user.email);
        }
        StringBuilder sb = new StringBuilder("Team: " + Config.TEAM_NAME);
        for (String m : Config.MEMBERS) sb.append("\n• ").append(m);
        team.setText(sb.toString());
        github.setText(Config.GITHUB_URL);
        github.setOnClickListener(x -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Config.GITHUB_URL)));
            } catch (Exception e) {
                Snackbar.make(v, "No browser found", Snackbar.LENGTH_LONG).show();
            }
        });

        v.findViewById(R.id.btn_logout).setOnClickListener(x -> {
            Session.clear(requireContext());
            // Clear the whole back stack so Back cannot return to app screens (R2).
            Intent i = new Intent(requireContext(), LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }
}
