package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {
    private TextInputLayout nameL, emailL, passL, confL;
    private TextInputEditText name, email, pass, conf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        nameL = findViewById(R.id.til_name);
        emailL = findViewById(R.id.til_email);
        passL = findViewById(R.id.til_password);
        confL = findViewById(R.id.til_confirm);
        name = findViewById(R.id.et_name);
        email = findViewById(R.id.et_email);
        pass = findViewById(R.id.et_password);
        conf = findViewById(R.id.et_confirm);

        findViewById(R.id.btn_register).setOnClickListener(v -> attemptRegister());
        findViewById(R.id.btn_go_login).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void attemptRegister() {
        String n = text(name), m = text(email), p = text(pass), c = text(conf);
        nameL.setError(null);
        emailL.setError(null);
        passL.setError(null);
        confL.setError(null);

        boolean ok = true;
        String err;
        if ((err = Utils.validateName(n)) != null) {
            nameL.setError(err);
            ok = false;
        }
        if ((err = Utils.validateEmail(m)) != null) {
            emailL.setError(err);
            ok = false;
        }
        if ((err = Utils.validatePassword(p)) != null) {
            passL.setError(err);
            ok = false;
        }
        if (c.isEmpty()) {
            confL.setError("Confirm your password");
            ok = false;
        } else if (!c.equals(p)) {
            confL.setError("Passwords do not match");
            ok = false;
        }
        if (!ok) return;

        DbHelper db = DbHelper.get(this);
        if (db.getUserByEmail(m) != null) {
            emailL.setError("An account with this email already exists");
            return;
        }
        String salt = PasswordUtil.newSalt();
        long id = db.addUser(n.trim(), m.trim().toLowerCase(), salt, PasswordUtil.hash(salt, p));
        if (id < 0) {
            emailL.setError("An account with this email already exists");
            return;
        }
        Session.save(this, id);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private static String text(TextInputEditText t) {
        return t.getText() == null ? "" : t.getText().toString();
    }
}
