package com.uol.campusfind;

import android.util.Patterns;

import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Pattern;

public final class Utils {
    public static final String[] CATEGORIES =
            {"Electronics", "Wallets & Cards", "Keys", "Books & Stationery", "Other"};

    private static final Pattern NAME = Pattern.compile("^[A-Za-z ]+$");
    private static final Pattern DIGIT = Pattern.compile(".*\\d.*");
    private static final Pattern PHONE = Pattern.compile("^03\\d{9}$");

    private Utils() {}

    public static String isoToday() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    public static String prettyDate(String iso) {
        String[] m = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        String[] p = iso.split("-");
        return p[2] + "-" + m[Integer.parseInt(p[1]) - 1] + "-" + p[0];
    }

    /** R7: whole metres below 1,000 m, otherwise km with one decimal. */
    public static String formatDistance(float metres) {
        if (metres < 1000) return Math.round(metres) + " m";
        return String.format(Locale.US, "%.1f km", metres / 1000f);
    }

    public static String fmt5(double v) {
        return String.format(Locale.US, "%.5f", v);
    }

    public static double round5(double v) {
        return Math.round(v * 100000d) / 100000d;
    }

    // ---- validators: return an error message or null ----
    public static String validateName(String v) {
        String s = v.trim();
        if (s.isEmpty()) return "Full name is required";
        if (!NAME.matcher(s).matches()) return "Use letters and spaces only";
        if (s.length() < 3) return "At least 3 characters";
        return null;
    }

    public static String validateEmail(String v) {
        String s = v.trim();
        if (s.isEmpty()) return "Email is required";
        if (!Patterns.EMAIL_ADDRESS.matcher(s).matches()) return "Enter a valid email";
        return null;
    }

    public static String validatePassword(String v) {
        if (v.isEmpty()) return "Password is required";
        if (v.length() < 6) return "At least 6 characters";
        if (!DIGIT.matcher(v).matches()) return "Include at least one digit";
        return null;
    }

    public static String validateTitle(String v) {
        String s = v.trim();
        if (s.isEmpty()) return "Title is required";
        if (s.length() < 3) return "At least 3 characters";
        return null;
    }

    public static String validatePlace(String v) {
        return v.trim().isEmpty() ? "Place is required" : null;
    }

    public static String validateContact(String v) {
        String s = v.trim();
        if (s.isEmpty()) return "Contact number is required";
        if (!PHONE.matcher(s).matches()) return "11 digits starting with 03 (e.g. 03001234567)";
        return null;
    }
}
