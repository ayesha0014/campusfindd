package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButtonToggleGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private ItemAdapter adapter;
    private TextView empty;
    private List<Item> all = new ArrayList<>();
    private String filter = "All";
    private String query = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        RecyclerView rv = view.findViewById(R.id.recycler);
        empty = view.findViewById(R.id.tv_empty);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), ItemDetailsActivity.class);
            i.putExtra(ItemDetailsActivity.EXTRA_ID, item.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);

        EditText search = view.findViewById(R.id.et_search);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        MaterialButtonToggleGroup group = view.findViewById(R.id.toggle_filter);
        group.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.btn_lost) filter = "Lost";
            else if (checkedId == R.id.btn_found) filter = "Found";
            else filter = "All";
            applyFilter();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        all = DbHelper.get(requireContext()).getAllItems();
        applyFilter();
    }

    private void applyFilter() {
        if (adapter == null) return;
        List<Item> out = new ArrayList<>();
        for (Item it : all) {
            if (!"All".equals(filter) && !it.type.equals(filter)) continue;
            if (!query.isEmpty()
                    && !it.title.toLowerCase(Locale.ROOT).contains(query)
                    && !it.place.toLowerCase(Locale.ROOT).contains(query)
                    && !it.category.toLowerCase(Locale.ROOT).contains(query)) continue;
            out.add(it);
        }
        adapter.setData(out, null);
        empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
