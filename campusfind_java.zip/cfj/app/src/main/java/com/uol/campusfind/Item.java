package com.uol.campusfind;

public class Item {
    public final String id;
    public final int idNum;
    public final String type;
    public final String title;
    public final String category;
    public final String place;
    public final String contact;
    public final String date; // yyyy-MM-dd
    public final double lat;
    public final double lng;
    public final String status;
    public final String reportedBy;
    public final long reportedByUid; // -1 for Student Affairs

    public Item(String id, int idNum, String type, String title, String category, String place,
                String contact, String date, double lat, double lng, String status,
                String reportedBy, long reportedByUid) {
        this.id = id;
        this.idNum = idNum;
        this.type = type;
        this.title = title;
        this.category = category;
        this.place = place;
        this.contact = contact;
        this.date = date;
        this.lat = lat;
        this.lng = lng;
        this.status = status;
        this.reportedBy = reportedBy;
        this.reportedByUid = reportedByUid;
    }

    public boolean isReturned() {
        return "Returned".equals(status);
    }
}
