package com.uol.campusfind;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

/**
 * Asks for location permission at run time and fetches the device's current location (R4).
 * Create it as a field of a Fragment (it registers a permission launcher).
 */
public class LocationHelper {
    public interface Callback {
        void onLocation(Location location);

        void onDenied();

        void onError();
    }

    private final Fragment fragment;
    private final ActivityResultLauncher<String[]> launcher;
    private Callback pending;

    public LocationHelper(Fragment fragment) {
        this.fragment = fragment;
        this.launcher = fragment.registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                    boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))
                            || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                    Callback cb = pending;
                    if (cb == null) return;
                    if (granted) fetch(cb);
                    else cb.onDenied();
                });
    }

    public void request(Callback cb) {
        pending = cb;
        boolean has = ContextCompat.checkSelfPermission(fragment.requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(fragment.requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (has) fetch(cb);
        else launcher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION});
    }

    @SuppressLint("MissingPermission")
    private void fetch(Callback cb) {
        if (!fragment.isAdded()) return;
        FusedLocationProviderClient client =
                LocationServices.getFusedLocationProviderClient(fragment.requireContext());
        CancellationTokenSource cts = new CancellationTokenSource();
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
                .addOnSuccessListener(loc -> {
                    if (loc != null) {
                        cb.onLocation(loc);
                    } else {
                        client.getLastLocation()
                                .addOnSuccessListener(last -> {
                                    if (last != null) cb.onLocation(last);
                                    else cb.onError();
                                })
                                .addOnFailureListener(e -> cb.onError());
                    }
                })
                .addOnFailureListener(e -> cb.onError());
    }
}
