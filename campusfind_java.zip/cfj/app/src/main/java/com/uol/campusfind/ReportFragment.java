package com.uol.campusfind;

import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ReportFragment extends Fragment {
    private final LocationHelper loc = new LocationHelper(this);
    private MaterialButtonToggleGroup typeGroup;
    private TextInputLayout titleL, catL, placeL, contactL;
    private TextInputEditText title, place, contact;
    private AutoCompleteTextView category;
    private TextView locText;
    private Location position;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        typeGroup = v.findViewById(R.id.toggle_type);
        titleL = v.findViewById(R.id.til_title);
        catL = v.findViewById(R.id.til_category);
        placeL = v.findViewById(R.id.til_place);
        contactL = v.findViewById(R.id.til_contact);
        title = v.findViewById(R.id.et_title);
        place = v.findViewById(R.id.et_place);
        contact = v.findViewById(R.id.et_contact);
        category = v.findViewById(R.id.dd_category);
        locText = v.findViewById(R.id.tv_location);

        category.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, Utils.CATEGORIES));

        v.findViewById(R.id.btn_use_location).setOnClickListener(b -> fetchLocation());
        v.findViewById(R.id.btn_save).setOnClickListener(b -> save());
    }

    private void fetchLocation() {
        locText.setTextColor(requireContext().getColor(android.R.color.darker_gray));
        locText.setText("Getting location...");
        loc.request(new LocationHelper.Callback() {
            @Override
            public void onLocation(Location l) {
                if (!isAdded()) return;
                position = l;
                locText.setTextColor(0xFF00695C);
                locText.setText("Lat: " + Utils.fmt5(l.getLatitude()) + ", Lng: " + Utils.fmt5(l.getLongitude()));
            }

            @Override
            public void onDenied() {
                if (!isAdded()) return;
                position = null;
                showLocError("Location permission is required to tag this item");
            }

            @Override
            public void onError() {
                if (!isAdded()) return;
                position = null;
                showLocError("Could not get your location. Turn on GPS and try again.");
            }
        });
    }

    private void showLocError(String msg) {
        locText.setTextColor(0xFFB3261E);
        locText.setText(msg);
        Snackbar.make(requireView(), msg, Snackbar.LENGTH_LONG).show();
    }

    private static String t(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString();
    }

    private void save() {
        titleL.setError(null);
        catL.setError(null);
        placeL.setError(null);
        contactL.setError(null);

        boolean ok = true;
        String err;
        if ((err = Utils.validateTitle(t(title))) != null) {
            titleL.setError(err);
            ok = false;
        }
        String cat = category.getText() == null ? "" : category.getText().toString();
        if (cat.isEmpty()) {
            catL.setError("Select a category");
            ok = false;
        }
        if ((err = Utils.validatePlace(t(place))) != null) {
            placeL.setError(err);
            ok = false;
        }
        if ((err = Utils.validateContact(t(contact))) != null) {
            contactL.setError(err);
            ok = false;
        }
        if (position == null) {
            locText.setTextColor(0xFFB3261E);
            locText.setText("Tap \"Use my current location\" to tag this item");
            ok = false;
        }
        if (!ok) return;

        User user = Session.currentUser(requireContext());
        if (user == null) return;
        String type = typeGroup.getCheckedButtonId() == R.id.btn_found ? "Found" : "Lost";
        Item item = DbHelper.get(requireContext()).addItem(type, t(title), cat, t(place), t(contact),
                Utils.round5(position.getLatitude()), Utils.round5(position.getLongitude()), user);

        Snackbar.make(requireActivity().findViewById(android.R.id.content),
                "Item " + item.id + " saved", Snackbar.LENGTH_LONG).show();
        ((MainActivity) requireActivity()).selectTab(R.id.nav_home);
    }
}
