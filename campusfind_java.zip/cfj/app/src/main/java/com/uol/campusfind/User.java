package com.uol.campusfind;

public class User {
    public final long id;
    public final String name;
    public final String email;
    public final String salt;
    public final String hash;

    public User(long id, String name, String email, String salt, String hash) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.salt = salt;
        this.hash = hash;
    }
}
