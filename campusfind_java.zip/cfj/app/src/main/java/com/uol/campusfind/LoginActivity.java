package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {
    private TextInputLayout emailLayout, passLayout;
    private TextInputEditText email, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Already logged in (session survives app restarts)? Go straight to the app.
        if (Session.currentUser(this) != null) {
            goMain();
            return;
        }
        setContentView(R.layout.activity_login);
        emailLayout = findViewById(R.id.til_email);
        passLayout = findViewById(R.id.til_password);
        email = findViewById(R.id.et_email);
        pass = findViewById(R.id.et_password);

        findViewById(R.id.btn_login).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btn_go_register).setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
            finish();
        });
    }

    private void attemptLogin() {
        String mail = text(email);
        String pw = text(pass);
        emailLayout.setError(null);
        passLayout.setError(null);
        boolean ok = true;
        String e1 = Utils.validateEmail(mail);
        if (e1 != null) {
            emailLayout.setError(e1);
            ok = false;
        }
        if (pw.isEmpty()) {
            passLayout.setError("Password is required");
            ok = false;
        }
        if (!ok) return;

        User u = DbHelper.get(this).getUserByEmail(mail);
        if (u == null || !PasswordUtil.hash(u.salt, pw).equals(u.hash)) {
            Snackbar.make(findViewById(android.R.id.content), "Invalid email or password",
                    Snackbar.LENGTH_LONG).show();
            return;
        }
        Session.save(this, u.id);
        goMain();
    }

    private void goMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private static String text(TextInputEditText t) {
        return t.getText() == null ? "" : t.getText().toString();
    }
}
