package com.uol.campusfind;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
    public interface OnItemClick {
        void onClick(Item item);
    }

    private final List<Item> items = new ArrayList<>();
    private Map<String, String> extra; // optional per-item line (e.g. distance)
    private final OnItemClick listener;

    public ItemAdapter(OnItemClick listener) {
        this.listener = listener;
    }

    public void setData(List<Item> data, Map<String, String> extraLines) {
        items.clear();
        items.addAll(data);
        extra = extraLines;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Item it = items.get(position);
        h.title.setText(it.title);
        h.details.setText(it.category + "  •  " + it.place);
        String line = (extra != null && extra.containsKey(it.id)) ? extra.get(it.id) : Utils.prettyDate(it.date);
        h.line3.setText(line);
        boolean lost = "Lost".equals(it.type);
        h.type.setText(it.type.toUpperCase());
        h.type.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(lost ? "#FFDAD6" : "#A7F0E1")));
        h.returned.setVisibility(it.isReturned() ? View.VISIBLE : View.GONE);
        h.itemView.setOnClickListener(v -> listener.onClick(it));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView title, details, line3, type, returned;

        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.tv_title);
            details = v.findViewById(R.id.tv_details);
            line3 = v.findViewById(R.id.tv_line3);
            type = v.findViewById(R.id.tv_type);
            returned = v.findViewById(R.id.tv_returned);
        }
    }
}
