package com.uol.campusfind;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Local SQLite database: users + items. Seeds the 6 starter items on first run. */
public class DbHelper extends SQLiteOpenHelper {
    private static final String NAME = "campusfind.db";
    private static final int VERSION = 1;
    private static DbHelper instance;

    public static synchronized DbHelper get(Context c) {
        if (instance == null) instance = new DbHelper(c.getApplicationContext());
        return instance;
    }

    private DbHelper(Context c) {
        super(c, NAME, null, VERSION);
    }

    private static final Object[][] STARTER = {
            {"Found", "Black leather wallet", "Wallets & Cards", "Main Library", "2026-11-12", 31.38955, 74.24070},
            {"Lost", "Casio fx-991ES calculator", "Electronics", "CS Block", "2026-11-11", 31.38990, 74.24120},
            {"Found", "Student ID card", "Wallets & Cards", "Cafeteria", "2026-11-10", 31.38880, 74.24010},
            {"Lost", "Blue water bottle", "Other", "Sports Ground", "2026-11-09", 31.38800, 74.24200},
            {"Found", "Car keys, red keychain", "Keys", "Main Parking", "2026-11-08", 31.39050, 74.23950},
            {"Lost", "32 GB USB flash drive", "Electronics", "Mosque", "2026-11-07", 31.38920, 74.24180}
    };

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, "
                + "email TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, hash TEXT NOT NULL)");
        db.execSQL("CREATE TABLE items(id TEXT PRIMARY KEY, idNum INTEGER NOT NULL, type TEXT NOT NULL, "
                + "title TEXT NOT NULL, category TEXT NOT NULL, place TEXT NOT NULL, contact TEXT NOT NULL, "
                + "date TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL, status TEXT NOT NULL, "
                + "reportedBy TEXT NOT NULL, reportedByUid INTEGER NOT NULL)");
        for (int i = 0; i < STARTER.length; i++) {
            Object[] s = STARTER[i];
            ContentValues v = new ContentValues();
            v.put("id", String.format("CF-%02d", i + 1));
            v.put("idNum", i + 1);
            v.put("type", (String) s[0]);
            v.put("title", (String) s[1]);
            v.put("category", (String) s[2]);
            v.put("place", (String) s[3]);
            v.put("contact", "N/A");
            v.put("date", (String) s[4]);
            v.put("lat", (Double) s[5]);
            v.put("lng", (Double) s[6]);
            v.put("status", "Open");
            v.put("reportedBy", "Student Affairs");
            v.put("reportedByUid", -1);
            db.insert("items", null, v);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // no migrations needed for this prototype
    }

    // ---------------- users ----------------
    public long addUser(String name, String email, String salt, String hash) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("email", email);
        v.put("salt", salt);
        v.put("hash", hash);
        return getWritableDatabase().insert("users", null, v);
    }

    private User userFromCursor(Cursor c) {
        return new User(c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("email")),
                c.getString(c.getColumnIndexOrThrow("salt")),
                c.getString(c.getColumnIndexOrThrow("hash")));
    }

    public User getUserByEmail(String email) {
        try (Cursor c = getReadableDatabase().query("users", null, "email = ?",
                new String[]{email.trim().toLowerCase()}, null, null, null)) {
            return c.moveToFirst() ? userFromCursor(c) : null;
        }
    }

    public User getUserById(long id) {
        try (Cursor c = getReadableDatabase().query("users", null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null)) {
            return c.moveToFirst() ? userFromCursor(c) : null;
        }
    }

    // ---------------- items ----------------
    private Item itemFromCursor(Cursor c) {
        return new Item(c.getString(c.getColumnIndexOrThrow("id")),
                c.getInt(c.getColumnIndexOrThrow("idNum")),
                c.getString(c.getColumnIndexOrThrow("type")),
                c.getString(c.getColumnIndexOrThrow("title")),
                c.getString(c.getColumnIndexOrThrow("category")),
                c.getString(c.getColumnIndexOrThrow("place")),
                c.getString(c.getColumnIndexOrThrow("contact")),
                c.getString(c.getColumnIndexOrThrow("date")),
                c.getDouble(c.getColumnIndexOrThrow("lat")),
                c.getDouble(c.getColumnIndexOrThrow("lng")),
                c.getString(c.getColumnIndexOrThrow("status")),
                c.getString(c.getColumnIndexOrThrow("reportedBy")),
                c.getLong(c.getColumnIndexOrThrow("reportedByUid")));
    }

    /** R6: newest first; same date -> higher ID first. */
    public List<Item> getAllItems() {
        List<Item> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("items", null, null, null, null, null,
                "date DESC, idNum DESC")) {
            while (c.moveToNext()) list.add(itemFromCursor(c));
        }
        return list;
    }

    public Item getItem(String id) {
        try (Cursor c = getReadableDatabase().query("items", null, "id = ?",
                new String[]{id}, null, null, null)) {
            return c.moveToFirst() ? itemFromCursor(c) : null;
        }
    }

    /** R5: next ID, today's date, status Open, reported by the logged-in user. */
    public Item addItem(String type, String title, String category, String place, String contact,
                        double lat, double lng, User user) {
        SQLiteDatabase db = getWritableDatabase();
        int next = 1;
        try (Cursor c = db.rawQuery("SELECT MAX(idNum) FROM items", null)) {
            if (c.moveToFirst()) next = c.getInt(0) + 1;
        }
        Item item = new Item(String.format("CF-%02d", next), next, type, title.trim(), category,
                place.trim(), contact.trim(), Utils.isoToday(), lat, lng, "Open", user.name, user.id);
        ContentValues v = new ContentValues();
        v.put("id", item.id);
        v.put("idNum", item.idNum);
        v.put("type", item.type);
        v.put("title", item.title);
        v.put("category", item.category);
        v.put("place", item.place);
        v.put("contact", item.contact);
        v.put("date", item.date);
        v.put("lat", item.lat);
        v.put("lng", item.lng);
        v.put("status", item.status);
        v.put("reportedBy", item.reportedBy);
        v.put("reportedByUid", item.reportedByUid);
        db.insert("items", null, v);
        return item;
    }

    public void markReturned(String id) {
        ContentValues v = new ContentValues();
        v.put("status", "Returned");
        getWritableDatabase().update("items", v, "id = ?", new String[]{id});
    }
}
